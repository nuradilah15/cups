package com.dicoding.picodiploma.coba.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.dicoding.picodiploma.coba.R;

public class CommentApps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment_apps);
    }
}