package com.dicoding.picodiploma.coba.activity

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import com.dicoding.picodiploma.coba.DataClass
import com.dicoding.picodiploma.coba.R
import com.dicoding.picodiploma.coba.databinding.ActivityAddBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.*

class AddActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddBinding
    private lateinit var dbRef: DatabaseReference
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    var imageURL: String? = null
    var uri: Uri? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        dbRef =FirebaseDatabase.getInstance().getReference("users")
        val activityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
            ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                uri = data!!.data
                binding.imageView3.setImageURI(uri)
            } else {
                Toast.makeText(this@AddActivity, "No Image Selected", Toast.LENGTH_SHORT).show()
            }
        }
        binding.imageView3.setOnClickListener {
            val photoPicker = Intent(Intent.ACTION_PICK)
            photoPicker.type = "image/*"
            activityResultLauncher.launch(photoPicker)
        }
        binding.btnUpload.setOnClickListener {
            saveData()
        }
    }

    private fun saveData(){
        val baos = ByteArrayOutputStream()
        val reference = FirebaseStorage.getInstance().reference.child("img_user/${FirebaseAuth.getInstance().currentUser?.email}")

        val builder = AlertDialog.Builder(this@AddActivity)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

//        reference.putFile((uri!!)).addOnCompleteListener {
//            if (it.isSuccessful) {
//                Toast.makeText(this, "Uploading data, Please wait... ", Toast.LENGTH_SHORT).show()
//                reference.downloadUrl.addOnSuccessListener { task ->
//                    uploadData()
//                }
//            }
//        }

       reference.putFile(uri!!).addOnSuccessListener { taskSnapshot ->
           val uriTask = taskSnapshot.storage.downloadUrl
           while (!uriTask.isComplete);
           val urlImage = uriTask.result
           imageURL = urlImage.toString()
           uploadData()
           dialog.dismiss()
       }.addOnFailureListener {
           dialog.dismiss()
       }


        }

    private fun uploadData() {
        val desc = binding.etDescription.text.toString()
        val dataClass = DataClass(desc,imageURL)
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        val userId = dbRef.push().key!!
        val currentData = DateFormat.getDateInstance().format(Calendar.getInstance().time)
        val user = DataClass( binding.etDescription.text.toString(), imageURL
        )

        database.reference.child("users").child(uid).child(userId).setValue(user)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@AddActivity,"Saved",Toast.LENGTH_SHORT).show()
                    finish()
            }
    }.addOnFailureListener {e ->
                Toast.makeText(this@AddActivity,e.message.toString(),Toast.LENGTH_SHORT).show()
            }
}
}