package com.dicoding.picodiploma.coba

data class Users(
    var nama : String?=null,
    var email : String?=null,
    var userId : String?= null,
    var uid : String?= null
)
