package com.dicoding.picodiploma.coba.activity


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import com.dicoding.picodiploma.coba.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.dicoding.picodiploma.coba.R
import com.dicoding.picodiploma.coba.adapter.ViewPagerAdapter
import com.dicoding.picodiploma.coba.fragment.HomeFragment
import com.dicoding.picodiploma.coba.fragment.UserFragment


class MainActivity : AppCompatActivity() {

    lateinit var _bind : ActivityMainBinding
    lateinit var auth : FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        _bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(_bind.root)
        tabsSetup()
    }

    private fun tabsSetup() {
        val adapter = ViewPagerAdapter(supportFragmentManager)
        adapter.addFrag(HomeFragment(),"Home")
        adapter.addFrag(UserFragment(),"User")

        _bind.viewPager.adapter = adapter
        _bind.tabs.setupWithViewPager(_bind.viewPager)

        _bind.tabs.getTabAt(0)!!.setIcon(R.drawable.ic_baseline_home_24)
        _bind.tabs.getTabAt(1)!!.setIcon(R.drawable.ic_baseline_person_24)
    }


}


